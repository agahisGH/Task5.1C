package com.example.task51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import org.w3c.dom.Text;

import java.util.List;

public class RVTopStoriesAdapter extends RecyclerView.Adapter<RVTopStoriesAdapter.ViewHolder>
{
    private List<TopStoriesData> topStoriesData;
    private Context context;
    private OnTopClickListener listener;

    public RVTopStoriesAdapter(List<TopStoriesData> topStoriesData, Context context, OnTopClickListener clickListener) {
        this.topStoriesData = topStoriesData;
        this.context = context;
        this.listener = clickListener;
    }

    @NonNull
    @Override
    public RVTopStoriesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemViewTopStories = LayoutInflater.from(context).inflate(R.layout.topstories_rv_item, parent, false);

        return new ViewHolder(itemViewTopStories, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull RVTopStoriesAdapter.ViewHolder holder, int position) {
        holder.topStoryImage.setImageResource(topStoriesData.get(position).getImage());
        holder.topStoryTitle.setText(topStoriesData.get(position).getTitle());
    }

    @Override
    public int getItemCount() {
        return topStoriesData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView topStoryImage;
        TextView topStoryTitle;
        OnTopClickListener onTopClickListener;

        public ViewHolder(@NonNull View itemView, OnTopClickListener onTopClickListener) {
            super(itemView);
            topStoryImage = itemView.findViewById(R.id.imageViewStory1);
            topStoryTitle = itemView.findViewById(R.id.textViewStory1);

            this.onTopClickListener = onTopClickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onTopClickListener.onItemClickTop(getAdapterPosition());
        }
    }

    public interface OnTopClickListener {
        void onItemClickTop(int position);
    }
}
