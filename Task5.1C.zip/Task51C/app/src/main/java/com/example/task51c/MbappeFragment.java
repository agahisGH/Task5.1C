package com.example.task51c;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MbappeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MbappeFragment extends Fragment {

    RecyclerView recyclerViewRelated;
    RVRelatedAdapter recyclerViewAdapterRelated;
    List<RelatedData> relatedDataList = new ArrayList<>();

    Integer[] imageList2 = {R.drawable.benzema, R.drawable.realmadrid, R.drawable.liverpool};
    String[] titleList2 = {"ABC News", "7 News", "9 News"};
    String[] descriptionList2 = {"Karim Benzema Wins 2022 Ballon d'Or", "Real Madrid Advance to UCL Final", "Liverpool Crowned Premier League Champions"};

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MbappeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MbappeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MbappeFragment newInstance(String param1, String param2) {
        MbappeFragment fragment = new MbappeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

//    @Override
//    public void onItemClickRelated(int position) {
//        Fragment fragment;
//
//        switch (position) {
//            case 0:
//                fragment = new BenzemaFragment();
//                break;
//            case 1:
//                fragment = new RealMadridFragment();
//                break;
//            case 2:
//                fragment = new LiverpoolFragment();
//                break;
//            default:
//                throw new IllegalStateException("Unexpected Value: " + position);
//        }
//
//        FragmentManager fragmentManagerBatman = getFragmentManager();
//        FragmentTransaction fragmentTransactionBatman = fragmentManagerBatman.beginTransaction();
//        fragmentTransactionBatman.replace(R.id.defaultFragment, fragment).addToBackStack(null).commit();
//    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_mbappe, container, false);

        recyclerViewRelated = view.findViewById(R.id.RVRelated);

        recyclerViewAdapterRelated = new RVRelatedAdapter(relatedDataList, getActivity());
        recyclerViewRelated.setAdapter(recyclerViewAdapterRelated);

        for (int i = 0; i < titleList2.length; i++)
        {
            RelatedData newsData2 = new RelatedData(i, imageList2[i], titleList2[i], descriptionList2[i]);
            relatedDataList.add(newsData2);
        }

        return view;
    }
}
