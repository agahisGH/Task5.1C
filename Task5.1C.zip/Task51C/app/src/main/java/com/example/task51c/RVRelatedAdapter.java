package com.example.task51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RVRelatedAdapter extends RecyclerView.Adapter<RVRelatedAdapter.ViewHolder> {
    private List<RelatedData> relatedData;
    private Context context;
    //private OnRelatedClickListener listener;

    public RVRelatedAdapter(List<RelatedData> relatedData, Context context) { //OnRelatedClickListener clickListener
        this.relatedData = relatedData;
        this.context = context;
        //this.listener = clickListener;
    }

    @NonNull
    @Override
    public RVRelatedAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemViewRelated = LayoutInflater.from(context).inflate(R.layout.news_rv_item, parent, false);

        return new ViewHolder(itemViewRelated); //,listner
    }

    @Override
    public void onBindViewHolder(@NonNull RVRelatedAdapter.ViewHolder holder, int position) {
        holder.newsImageR.setImageResource(relatedData.get(position).getImage());
        holder.newsStoryR.setText(relatedData.get(position).getTitle());
        holder.newsTitleR.setText(relatedData.get(position).getDescription());
    }

    @Override
    public int getItemCount() {
        return relatedData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView newsImageR;
        TextView newsStoryR;
        TextView newsTitleR;
        //OnRelatedClickListener onRelatedClickListener;

        public ViewHolder(@NonNull View itemView) { //, OnRelatedClickListener onRelatedClickListener
            super(itemView);
            newsImageR = itemView.findViewById(R.id.imageViewNews1);
            newsStoryR = itemView.findViewById(R.id.textViewNews1);
            newsTitleR = itemView.findViewById(R.id.textViewNews1SubTitle);

//            this.onRelatedClickListener = onRelatedClickListener;
//            itemView.setOnClickListener((View.OnClickListener) this);
//            }

//        @Override
//        public void onClick(View view) {
//            onRelatedClickListener.onItemClickRelated(getAdapterPosition());
//        }
//
//    public interface OnRelatedClickListener {
//        void onItemClickRelated(int position);
//    }
        }
    }
}
