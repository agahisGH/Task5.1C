package com.example.task51c;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements RVNewsAdapter.OnRowClickListener {

    RecyclerView recyclerViewTopStories;
    RVTopStoriesAdapter recyclerViewAdapterTop;
    List<TopStoriesData> topStoriesDataList = new ArrayList<>();

    Integer[] imageListTopStories = {R.drawable.bitcoin, R.drawable.batman, R.drawable.mbappe, R.drawable.spiderman};
    String[] titleListTopStories = {"The Age", "9 News", "ABC News", "7 News"};

    RecyclerView recyclerViewNews;
    RVNewsAdapter recyclerViewAdapter;
    List<NewsData> newsDataList = new ArrayList<>();

    Integer[] imageList = {R.drawable.benzema, R.drawable.liverpool, R.drawable.realmadrid, R.drawable.dogecoin};
    String[] titleList = {"ABC News", "9 News", "7 News", "The Age"};
    String[] descriptionList = {"Karim Benzema Wins 2022 Ballon d'Or", "Liverpool Crowned Premier League Champions", "Real Madrid Advance to UCL Final", "Dogecoin Price Rises 25%"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerViewTopStories = findViewById(R.id.RVTopStories);
        recyclerViewNews = findViewById(R.id.RVNews);

        recyclerViewAdapterTop = new RVTopStoriesAdapter(topStoriesDataList, this, this::onItemClickTop);
        recyclerViewTopStories.setAdapter(recyclerViewAdapterTop);

        for (int i = 0; i < imageListTopStories.length; i++)
        {
            TopStoriesData topStoriesData = new TopStoriesData(i, imageListTopStories[i], titleListTopStories[i]);
            topStoriesDataList.add(topStoriesData);
        }

        recyclerViewAdapter = new RVNewsAdapter(newsDataList, this, this);
        recyclerViewNews.setAdapter(recyclerViewAdapter);

        for (int i = 0; i < titleList.length; i++)
        {
            NewsData newsData = new NewsData(i, imageList[i], titleList[i], descriptionList[i]);
            newsDataList.add(newsData);
        }
    }

    @Override
    public void onItemClick(int position) {
        Fragment fragment;

        switch (position) {
            case 0:
                fragment = new BenzemaFragment();
                break;
            case 1:
                fragment = new LiverpoolFragment();
                break;
            case 2:
                fragment = new RealMadridFragment();
                break;
            case 3:
                fragment = new DogecoinFragment();
                break;
            default:
                throw new IllegalStateException("Unexpected Value: " + position);
        }

        FragmentManager fragmentManager = getSupportFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.replace(R.id.defaultFragment, fragment).addToBackStack(null).commit();
    }

    @Override
    public void onItemClickTop(int position) {
        Fragment fragment;

        switch (position) {
            case 0:
                fragment = new BitcoinFragment();
                break;
            case 1:
                fragment = new BatmanFragment();
                break;
            case 2:
                fragment = new MbappeFragment();
                break;
            case 3:
                fragment = new SpidermanFragment();
                break;
            default:
                throw new IllegalStateException("Unexpected Value: " + position);
        }

        FragmentManager fragmentManagerTop = getSupportFragmentManager();
        FragmentTransaction fragmentTransactionTop = fragmentManagerTop.beginTransaction();
        fragmentTransactionTop.replace(R.id.defaultFragment, fragment).addToBackStack(null).commit();
    }
}
