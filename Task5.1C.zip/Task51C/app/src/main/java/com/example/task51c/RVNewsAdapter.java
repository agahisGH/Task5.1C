package com.example.task51c;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RVNewsAdapter extends RecyclerView.Adapter<RVNewsAdapter.ViewHolder>
{
    private List<NewsData> newsData;
    private Context context;
    private OnRowClickListener listener;

    public RVNewsAdapter(List<NewsData> newsData, Context context, OnRowClickListener clickListener) {
        this.newsData = newsData;
        this.context = context;
        this.listener = clickListener;
    }

    @NonNull
    @Override
    public RVNewsAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(context).inflate(R.layout.news_rv_item, parent, false);

        return new ViewHolder(itemView, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull RVNewsAdapter.ViewHolder holder, int position) {
        holder.newsImage.setImageResource(newsData.get(position).getImage());
        holder.newsStory.setText(newsData.get(position).getTitle());
        holder.newsTitle.setText(newsData.get(position).getDescription());
    }

    @Override
    public int getItemCount() {
        return newsData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView newsImage;
        TextView newsStory;
        TextView newsTitle;
        OnRowClickListener onRowClickListener;

        public ViewHolder(@NonNull View itemView, OnRowClickListener onRowClickListener) {
            super(itemView);
            newsImage = itemView.findViewById(R.id.imageViewNews1);
            newsStory = itemView.findViewById(R.id.textViewNews1);
            newsTitle = itemView.findViewById(R.id.textViewNews1SubTitle);

            this.onRowClickListener = onRowClickListener;
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            onRowClickListener.onItemClick(getAdapterPosition());
        }
    }

    public interface OnRowClickListener {
        void onItemClick(int position);

        void onItemClickTop(int position);
    }
}
